'use strict';

var app = angular.module('myApp',['ngResource', 'ngAnimate', 'ui.bootstrap']);